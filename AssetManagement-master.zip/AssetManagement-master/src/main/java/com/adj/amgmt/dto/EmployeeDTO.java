
package com.adj.amgmt.dto;

import lombok.Data;

@Data
public class EmployeeDTO {
	private Integer employeeId;
	private String email;
	private String firstName;
	private String lastName;
}
