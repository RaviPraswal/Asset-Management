package com.adj.amgmt.service;


public interface AssetService {

}
